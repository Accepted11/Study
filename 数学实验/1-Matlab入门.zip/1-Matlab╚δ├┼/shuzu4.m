a=[2 2 2]
b=[3 3 3]
c1=a+b
c2=a.*b
c3=a./b
c4=a.\b
c5=a.^b